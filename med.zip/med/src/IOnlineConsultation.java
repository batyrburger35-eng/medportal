public interface IOnlineConsultation {
    void conductOnlineConsultation(Patient patient);
}
