public class Cardiologist extends Doctor {
    public Cardiologist(String name, int experience) {
        super(name, experience);
    }

    @Override
    public String getSpecialization() {
        return "Кардиолог";
    }

    @Override
    public void Reception() {
        System.out.println("Кардиолог проверяет работу сердечно-сосудистой системы");
    }
}
