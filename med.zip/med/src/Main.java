import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        Neurologist doctor = new Neurologist("Елена Смирнова", 12);
        Patient patient = new Patient("Иван Петров", 34, "Мигрень");
        Appointment appointment = new Appointment(patient, doctor, LocalDate.of(2026, 11, 20));

        patient.ShowPatientInfo();
        appointment.ShowAppointment();
        doctor.Reception();

        Therapist therapist = new Therapist("Анна Морозова", 8);
        therapist.conductOnlineConsultation(patient);
    }
}
