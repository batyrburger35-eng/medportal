public class Patient {
    private final String name;
    private final int age;
    private final String diagnosis;

    public Patient(String name, int age, String diagnosis) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Имя пациента не может быть пустым");
        }
        if (age < 0) {
            throw new IllegalArgumentException("Возраст не может быть отрицательным");
        }
        if (diagnosis == null || diagnosis.isBlank()) {
            throw new IllegalArgumentException("Диагноз не может быть пустым");
        }
        this.name = name;
        this.age = age;
        this.diagnosis = diagnosis;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public void ShowPatientInfo() {
        System.out.printf("Пациент: %s, возраст: %d, диагноз: %s%n", name, age, diagnosis);
    }
}
