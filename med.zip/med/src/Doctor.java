public abstract class Doctor {
    private final String name;
    private final int experience;

    protected Doctor(String name, int experience) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Имя врача не может быть пустым");
        }
        if (experience < 0) {
            throw new IllegalArgumentException("Стаж не может быть отрицательным");
        }
        this.name = name;
        this.experience = experience;
    }

    public String getName() {
        return name;
    }

    public int getExperience() {
        return experience;
    }

    public abstract String getSpecialization();

    public abstract void Reception();
}
