import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Appointment {
    private final Patient patient;
    private final Doctor doctor;
    private final LocalDate appointmentDate;

    public Appointment(Patient patient, Doctor doctor, LocalDate appointmentDate) {
        if (patient == null || doctor == null || appointmentDate == null) {
            throw new IllegalArgumentException("Пациент, врач и дата приёма обязательны");
        }
        this.patient = patient;
        this.doctor = doctor;
        this.appointmentDate = appointmentDate;
    }

    public Patient getPatient() {
        return patient;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public LocalDate getAppointmentDate() {
        return appointmentDate;
    }

    public void ShowAppointment() {
        String date = appointmentDate.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));
        System.out.printf(
                "Запись на приём: %s — %s, врач: %s (%s), стаж: %d лет%n",
                date,
                patient.getName(),
                doctor.getName(),
                doctor.getSpecialization(),
                doctor.getExperience()
        );
    }
}
