public class Therapist extends Doctor implements IOnlineConsultation {
    public Therapist(String name, int experience) {
        super(name, experience);
    }

    @Override
    public String getSpecialization() {
        return "Терапевт";
    }

    @Override
    public void Reception() {
        System.out.println("Терапевт проводит общий осмотр");
    }

    @Override
    public void conductOnlineConsultation(Patient patient) {
        System.out.printf("Терапевт проводит онлайн-консультацию для пациента %s%n", patient.getName());
    }
}
