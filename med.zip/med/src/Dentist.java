public class Dentist extends Doctor {
    public Dentist(String name, int experience) {
        super(name, experience);
    }

    @Override
    public String getSpecialization() {
        return "Стоматолог";
    }

    @Override
    public void Reception() {
        System.out.println("Стоматолог проводит осмотр полости рта");
    }
}
