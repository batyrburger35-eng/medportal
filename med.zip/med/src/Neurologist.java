public class Neurologist extends Doctor {
    public Neurologist(String name, int experience) {
        super(name, experience);
    }

    @Override
    public String getSpecialization() {
        return "Невролог";
    }

    @Override
    public void Reception() {
        System.out.println("Невролог проводит проверку нервной системы");
    }
}
